from pathlib import Path
import os,json,subprocess,datetime
repo=Path('/home/louishyh/projects/NovaCode')
root=Path.home()/'.cache/novacode-evaluation/stage8-authenticated'
command=[str(repo/'.venv/bin/python'),'evaluation/live/curate.py','select','--pool',str(root/'pool-final'),'--archive',str(root.parent/'stage8/runtime.tar')]
env={**os.environ,'DOCKER_CONFIG':str(Path.home()/'snap/docker/current/.docker'),'PATH':'/snap/bin:'+os.environ['PATH']}
with (root/'selection-after-interruption-1.log').open('x') as log:
 result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
with (root/'selection-after-interruption-1.json').open('x') as f:
 json.dump({'command':command,'exit_code':result.returncode,'ended_at':datetime.datetime.now(datetime.UTC).isoformat()},f,indent=2);f.write('\n')
