def start(values):
    return {"active_mode": values["mode"]}
