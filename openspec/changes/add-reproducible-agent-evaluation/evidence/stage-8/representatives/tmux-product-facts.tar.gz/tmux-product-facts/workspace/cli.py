from settings import load, resolve
from runtime import start

def main(path, overrides):
    return start(resolve(load(path), overrides))
