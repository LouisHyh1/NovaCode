import json

def load(path):
    with open(path) as stream:
        return json.load(stream)

def resolve(file_values, overrides):
    result = {"mode": "safe", "label": "default"}
    result.update(file_values)
    result.update(overrides)
    return result
