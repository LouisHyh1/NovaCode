import json,subprocess,sys
from pathlib import Path
p=Path(sys.argv[1])
r=subprocess.run(json.loads(p.read_text()))
p.with_name('tui-exited').write_text(str(r.returncode))
raise SystemExit(r.returncode)
