#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 0005c85fccccb491930f064ea8d064e87ce7ee79 tests/messages/test_pofile.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/messages/test_pofile.py b/tests/messages/test_pofile.py
index f4360ecf1..ed9da78f6 100644
--- a/tests/messages/test_pofile.py
+++ b/tests/messages/test_pofile.py
@@ -948,6 +948,19 @@ def test_tab_in_location_already_enclosed(self):
 msgstr ""'''
 
 
+    def test_wrap_with_enclosed_file_locations(self):
+        # Ensure that file names containing white space are not wrapped regardless of the --width parameter
+        catalog = Catalog()
+        catalog.add('foo', locations=[('\u2068test utils.py\u2069', 1)])
+        catalog.add('foo', locations=[('\u2068test utils.py\u2069', 3)])
+        buf = BytesIO()
+        pofile.write_po(buf, catalog, omit_header=True, include_lineno=True, width=1)
+        assert buf.getvalue().strip() == b'''#: \xe2\x81\xa8test utils.py\xe2\x81\xa9:1
+#: \xe2\x81\xa8test utils.py\xe2\x81\xa9:3
+msgid "foo"
+msgstr ""'''
+
+
 class RoundtripPoTestCase(unittest.TestCase):
 
     def test_enclosed_filenames_in_location_comment(self):

EOF_114329324912
: '>>>>> Start Test Output'
make test
pytest -rA
: '>>>>> End Test Output'
git checkout 0005c85fccccb491930f064ea8d064e87ce7ee79 tests/messages/test_pofile.py
